运行 service_recovery_3_25.py

如果项目文件夹下没有set_example_x.pkl文件，则首次运行时会生成该文件，且该次运行时间较长。如果有则无需生成